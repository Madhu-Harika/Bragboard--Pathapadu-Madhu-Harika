# BragBoard Admin Dashboard - Setup Instructions

Complete setup instructions for both frontend and backend.

## Project Overview

This is a full-stack admin dashboard application with:
- **Frontend**: React + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Backend**: FastAPI (Python)

## Frontend Setup (React)

### Prerequisites
- Node.js 18+ and npm installed

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Run the development server:**
   ```bash
   npm run dev
   ```

3. **Access the application:**
   - Frontend: `http://localhost:8080`
   - Default login route: `http://localhost:8080/login`

### Frontend Structure

```
src/
├── components/
│   ├── layout/
│   │   ├── DashboardLayout.tsx    # Main layout wrapper
│   │   ├── AppSidebar.tsx         # Sidebar navigation
│   │   └── DashboardNavbar.tsx    # Top navbar
│   ├── dashboard/
│   │   ├── StatCard.tsx           # Reusable stat card
│   │   └── DataTable.tsx          # Reusable data table
│   └── ui/                        # shadcn/ui components
├── pages/
│   ├── auth/
│   │   ├── Login.tsx              # Login page
│   │   └── Signup.tsx             # Signup page
│   └── dashboard/
│       ├── Overview.tsx           # Dashboard overview
│       ├── Users.tsx              # User management
│       ├── Moderation.tsx         # Shout-out moderation
│       ├── FlaggedContent.tsx     # Flagged content review
│       ├── Analytics.tsx          # Analytics & metrics
│       └── Settings.tsx           # Settings page
└── App.tsx                        # Main app with routing
```

### Available Routes

- `/login` - Admin login
- `/signup` - Admin signup
- `/dashboard` - Overview dashboard
- `/dashboard/users` - User management
- `/dashboard/moderation` - Shout-out moderation
- `/dashboard/flagged` - Flagged content
- `/dashboard/analytics` - Analytics
- `/dashboard/settings` - Settings

### Authentication

Currently uses localStorage for mock authentication:
- Login stores a token in `localStorage.getItem("adminToken")`
- Protected routes check for this token
- Replace with actual JWT authentication from backend

## Backend Setup (FastAPI)

### Prerequisites
- Python 3.8+ installed
- pip (Python package manager)

### Installation

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Create virtual environment:**
   ```bash
   python -m venv venv
   ```

3. **Activate virtual environment:**
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`

4. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Run the server:**
   ```bash
   python main.py
   ```
   
   Or with uvicorn:
   ```bash
   uvicorn main:app --reload --port 8000
   ```

6. **Access the API:**
   - API: `http://localhost:8000`
   - Swagger Docs: `http://localhost:8000/docs`
   - ReDoc: `http://localhost:8000/redoc`

### Backend Structure

```
backend/
├── main.py              # FastAPI application with all routes
├── requirements.txt     # Python dependencies
└── README.md           # Backend-specific instructions
```

## Connecting Frontend to Backend

### Option 1: Update API Base URL

Create `src/lib/api.ts`:
```typescript
const API_BASE_URL = "http://localhost:8000/api";

export const api = {
  async login(email: string, password: string) {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    return response.json();
  },
  // Add other API calls...
};
```

### Option 2: Update Frontend Auth Pages

Uncomment the API calls in:
- `src/pages/auth/Login.tsx`
- `src/pages/auth/Signup.tsx`

## Running Both Servers

### Terminal 1 - Frontend
```bash
npm run dev
```
Runs on: `http://localhost:8080`

### Terminal 2 - Backend
```bash
cd backend
source venv/bin/activate  # or venv\Scripts\activate on Windows
python main.py
```
Runs on: `http://localhost:8000`

## Default Credentials

Currently using mock authentication. Any email/password combination will work in development mode.

For production, implement:
1. Proper password hashing (bcrypt)
2. JWT token generation
3. Database integration for user storage

## Next Steps

### Immediate Enhancements
1. **Database Integration**
   - Add PostgreSQL or MySQL
   - Create proper schemas for users, shout-outs, etc.

2. **Real Authentication**
   - Implement JWT tokens in FastAPI
   - Add password hashing with bcrypt
   - Update frontend to use real tokens

3. **API Integration**
   - Connect all frontend pages to backend endpoints
   - Add error handling and loading states

### Advanced Features
4. **Data Visualization**
   - Integrate recharts for analytics charts
   - Add real-time data updates

5. **File Upload**
   - Add avatar upload functionality
   - Image handling for shout-outs

6. **Testing**
   - Add frontend tests (Vitest)
   - Add backend tests (pytest)

7. **Deployment**
   - Frontend: Vercel, Netlify, or AWS
   - Backend: Railway, Render, or AWS

## Troubleshooting

### CORS Issues
If you see CORS errors, ensure the backend CORS middleware includes your frontend URL:
```python
allow_origins=["http://localhost:8080"]
```

### Port Conflicts
- Frontend default: 8080 (change in `vite.config.ts`)
- Backend default: 8000 (change in `main.py`)

### Module Not Found
- Frontend: Run `npm install`
- Backend: Activate venv and run `pip install -r requirements.txt`

## Support

For issues or questions, refer to:
- React docs: https://react.dev
- FastAPI docs: https://fastapi.tiangolo.com
- shadcn/ui: https://ui.shadcn.com
